
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Rio"] = 242825.609,
	},
}
