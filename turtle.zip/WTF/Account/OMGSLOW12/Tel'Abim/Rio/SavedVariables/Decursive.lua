
Dcr_Saved = {
	["Print_CustomFrame"] = true,
	["Random_Order"] = false,
	["AfflictionTooltips"] = true,
	["SkipList"] = {
	},
	["LiveListTied"] = false,
	["CurePoison"] = true,
	["AlwaysUseBestSpell"] = true,
	["Amount_Of_Afflicted"] = 5,
	["Hide_LiveList"] = false,
	["ScanTime"] = 0.2,
	["Dcr_OutputWindow"] = ChatFrame1,
	["Dcr_Print_DEBUG_bis"] = false,
	["CureBlacklist"] = 5,
	["Ingore_Stealthed"] = false,
	["HideButtons"] = false,
	["CustomeFrameInsertBottom"] = false,
	["CureCurse"] = true,
	["CureMagic"] = true,
	["CureDisease"] = true,
	["Hidden"] = false,
	["Check_For_Abolish"] = true,
	["PlaySound"] = true,
	["DoNot_Blacklist_Prio_List"] = false,
	["Print_Error"] = true,
	["Scan_Pets"] = true,
	["Print_ChatFrame"] = false,
	["PriorityList"] = {
	},
	["ReverseLiveDisplay"] = false,
	["CureOrderList"] = {
		[1] = "Magic",
		[2] = "Curse",
		[3] = "Poison",
		[4] = "Disease",
	},
}
DCR_REMOTE_DEBUG = {
}