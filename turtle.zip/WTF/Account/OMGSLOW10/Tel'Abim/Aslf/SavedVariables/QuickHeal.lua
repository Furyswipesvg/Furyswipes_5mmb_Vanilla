
QuickHealVariables = {
	["DownrankValueNH"] = 12,
	["DownrankValueFH"] = 7,
}