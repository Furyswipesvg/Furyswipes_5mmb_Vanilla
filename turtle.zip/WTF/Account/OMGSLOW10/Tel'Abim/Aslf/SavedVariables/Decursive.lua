
Dcr_Saved = {
	["Print_CustomFrame"] = true,
	["Random_Order"] = false,
	["AfflictionTooltips"] = true,
	["SkipList"] = {
	},
	["AlwaysUseBestSpell"] = true,
	["CurePoison"] = true,
	["Ingore_Stealthed"] = false,
	["Amount_Of_Afflicted"] = 5,
	["Hide_LiveList"] = false,
	["LiveListTied"] = false,
	["Dcr_OutputWindow"] = ChatFrame1,
	["Dcr_Print_DEBUG_bis"] = false,
	["CureBlacklist"] = 5,
	["Hidden"] = false,
	["HideButtons"] = false,
	["ReverseLiveDisplay"] = false,
	["CustomeFrameInsertBottom"] = false,
	["CureCurse"] = true,
	["CureMagic"] = true,
	["CureDisease"] = true,
	["Check_For_Abolish"] = true,
	["PlaySound"] = true,
	["DoNot_Blacklist_Prio_List"] = false,
	["Print_Error"] = true,
	["Scan_Pets"] = true,
	["Print_ChatFrame"] = false,
	["PriorityList"] = {
	},
	["ScanTime"] = 0.2,
	["CureOrderList"] = {
		[1] = "Magic",
		[2] = "Curse",
		[3] = "Poison",
		[4] = "Disease",
	},
}
DCR_REMOTE_DEBUG = {
}