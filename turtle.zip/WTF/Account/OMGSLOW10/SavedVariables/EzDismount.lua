
EzDismount_Config = {
	["Aslf of Tel'Abim"] = {
		["Stand"] = "ON",
		["Dismount"] = "ON",
		["Druid"] = "ON",
		["Shadowform"] = "ON",
		["Wolf"] = "ON",
		["Auction"] = "ON",
		["Moonkin"] = "ON",
	},
}
