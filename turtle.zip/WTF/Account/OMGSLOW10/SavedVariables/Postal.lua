
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Aslf"] = 242824.562,
	},
}
