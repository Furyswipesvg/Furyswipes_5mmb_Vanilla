
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Summerlin"] = 242824.75,
	},
}
