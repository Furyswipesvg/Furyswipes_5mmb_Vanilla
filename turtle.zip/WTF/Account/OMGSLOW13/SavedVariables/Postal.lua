
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Redrock"] = 242825.984,
	},
}
