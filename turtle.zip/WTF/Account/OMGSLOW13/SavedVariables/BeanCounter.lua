
BeanCounterAccountDB = {
	["Tel'Abim"] = {
		["purchases"] = {
		},
		["completedAuctions"] = {
		},
		["pendingBids"] = {
		},
		["sales"] = {
		},
		["version"] = 30002,
		["completedBids"] = {
		},
		["players"] = {
			[1] = "Redrock",
		},
		["pendingAuctions"] = {
		},
	},
}
