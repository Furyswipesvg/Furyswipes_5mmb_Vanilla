
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Onlt"] = 242826.39,
	},
}
