
BattlefieldMinimapOptions = {
	["chronoboon"] = {
	},
	["showPlayers"] = true,
	["locked"] = true,
	["opacity"] = 0.7,
	["farclip"] = 777,
	["transmog"] = {
		["Furyswipes"] = {
			["Outfits"] = {
			},
		},
	},
}