
SM_VARS = {
	["macroTip1"] = 1,
	["printColor"] = {
		["r"] = 1,
		["g"] = 1,
		["b"] = 1,
	},
	["showMenu"] = 1,
	["minimap"] = 1,
	["hideAction"] = 0,
	["checkCooldown"] = 1,
	["wordWrap"] = 0,
	["replaceIcon"] = 1,
	["tabShown"] = "regular",
	["macroTip2"] = 0,
}
SM_EXTEND = {
}
SM_ACTION_SUPER = {
	["Furyswipes of Tel'Abim"] = {
		[65] = "flaoe",
	},
}
SM_SUPER = {
	["levparty"] = {
		[1] = "levparty",
		[2] = "Interface\\Icons\\Spell_Nature_EnchantArmor",
		[3] = "/script leveling_parties()",
	},
	["flaoe"] = {
		[1] = "flaoe",
		[2] = "Interface\\Icons\\Spell_Holy_Prayerofhealing02",
		[3] = "/script FloodAOEHeal()",
	},
}
