
Postal_Characters = {
	["Tel'Abim|Horde"] = {
		["Furyswipes"] = 242820.046,
	},
}
