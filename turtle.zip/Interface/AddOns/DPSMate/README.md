#!!MOVED TO GITHUB: https://github.com/Geigerkind!!#
# DPSMate #
#A combat analyzation tool#

#What is DPSMate?#
DPSMate is not only a meter which shows numbers of the raid, such as damage done, damage taken, dispells etc., it is moreover an analyzing tool to review the raid or the previous fight as accurately as possible. This data can help to improve the gameplay or to judge better over someones performance.

![img](http://i.imgur.com/UWEgLn9.png)

#Mentionable features of DPSMate#
Frame:   
- Several frames, allowing to show different modes at the same time   
- Resizable, allowing to adjust it to the interface   
- Fully costumizable by using the configuration menu   

Modes:   
- ~40 different modes   
Some of them are:   
- Healing and Absorbs (Effective healing and Absorbs)   
- Deaths, recall your or someones death   
- Dispells, showing everyones dispells including hot dispells such as Abolish Poison   
- Interrupts, including stuns and silences   
- Auras (Gained, Lost and Uptime)   
- Compare mode      
- etc.   

Misc:   
- Several Segments (Total, Current, and previous fights)   
- Synchronizing, to guarantee accurate data   
- Report function for every mode and everys player data   
- An own evaluation site to compare to revamp the raid and compare to other guilds: Legacy Logs (http://legacy-logs.com/#)  
- And many more...   

#But pictures tell more than words:#  
![img](http://i.imgur.com/gG3fHSR.png)  
![img](https://gyazo.com/df71a4bb0cdf5cb51cd51d96296177a6.png)  
![img](http://i.imgur.com/acsgyPb.gif)  
![img](http://i.imgur.com/R8yxnZX.png)  
![img](http://i.imgur.com/wWZHbeu.png)  
![img](http://i.imgur.com/Uezcowg.png)  
![img](http://i.imgur.com/Ine09Kp.png)  
![img](http://i.imgur.com/eEIL8i5.png)  
![img](https://gyazo.com/a045046b53246a133461939067a0dbc6.png)  

#**Download and install:**# (only english/german clients supported currently)
1. Download the addon folder here.
2. Rename the folder to "DPSMate"
3. I recommend to increase the addon memory to 150 mb.
4. Remove DPSMate.lua and DPSMate.lua.bak in your WTF/Account/YOUR ACC NAME/Kronos/YOUR CHAR NAME/SavedVariables/ (if you had DPSMate installed before)
5. I recommend to disable SW_Stats.

#**Legacy Logs!**#   http://legacy-logs.com/#
Legacy Logs is an world of logs-like evaluation site, using DPSMate to give you an indeph analyzation of your raid.   
It looks like this: (Link)   
![img](https://gyazo.com/31527f36b405dcd131ff495a4f96201b.png)  

#**Support me!**#   
1. https://bitbucket.org/tomdy/dpsmate/issues?status=new&status=open (report) bugs that you found.
2. Suggest improvements in this thread. 
3. You can also https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=57SWBZ3B7RTTQ (donate) for my projects if you like.

cheers!  
Shino